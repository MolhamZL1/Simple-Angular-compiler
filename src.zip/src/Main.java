import AST.Program;
import Code_Generation.CodeResult;
import SymbolTable.Component.ComponentSymbol;
import SymbolTable.Component.ComponentsSymboleTable;
import antlr.AngularLexer;
import antlr.AngularParser;
import LogHandler.ColorsConsole;
import LogHandler.LogHandler;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import utils.FileManager;
import visitor.BaseVisitor;
import visitor.SymbolTableInitializerVisitor;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;

import static org.antlr.v4.runtime.CharStreams.fromFileName;

public class Main {

    /* =================== إعدادات عامة =================== */

    private static final String ROOT = "src/Tests/";

    private static final Path DIST_DIR      = Paths.get("dist");
    private static final Path AST_DIR       = DIST_DIR.resolve("ast");
    private static final Path HTML_DIR      = DIST_DIR.resolve("html");
    private static final Path JS_DIR        = DIST_DIR.resolve("js");
    private static final Path SYMBOLS_FILE  = DIST_DIR.resolve("symbols.txt");

    private static final ComponentsSymboleTable componentsSymboleTable = new ComponentsSymboleTable();

    /* =================== Utilities =================== */

    private static boolean isComponentTs(File f) {
        return f != null && f.isFile() && f.getName().endsWith(".component.ts");
    }

    private static boolean isTargetToPrint(File f) {
        if (f == null || !f.isFile()) return false;
        String n = f.getName();
        return n.endsWith(".ts") || n.endsWith(".html");
    }

    private static ParseTree parse(String source) throws IOException {
        CharStream cs = fromFileName(source);
        AngularLexer lexer = new AngularLexer(cs);
        CommonTokenStream token = new CommonTokenStream(lexer);
        AngularParser parser = new AngularParser(token);
        return parser.program();
    }

    private static void ensureDirs() throws IOException {
        Files.createDirectories(DIST_DIR);
        Files.createDirectories(AST_DIR);
        Files.createDirectories(HTML_DIR);
        Files.createDirectories(JS_DIR);
    }

    /** مسار نسبي من ROOT بالنسبة للملف المعطى */
    private static Path relativeFromRoot(File file) {
        Path root = Paths.get(ROOT).toAbsolutePath().normalize();
        Path f    = file.toPath().toAbsolutePath().normalize();
        Path rel;
        try {
            rel = root.relativize(f);
        } catch (IllegalArgumentException e) {
            // إذا الملف خارج ROOT؛ نكتب باسمه فقط
            rel = Paths.get(file.getName());
        }
        return rel;
    }

    /** اسم الملف بدون اللاحقة */
    private static String stripExt(String name) {
        int i = name.lastIndexOf('.');
        return i > 0 ? name.substring(0, i) : name;
    }

    /** كتابة محتوى نصي بأمان باستخدام FileManager مع التأكد من وجود المجلد */
    private static void writeText(Path outPath, String content) throws IOException {
        Files.createDirectories(outPath.getParent());
        FileManager.writeFile(outPath.toString(), content == null ? "" : content);
    }

    /* =================== Symbol Table =================== */

    private static void setSymbolTable(File file) throws IOException {
        if (!isComponentTs(file)) return;

        String source = file.getPath();
        ParseTree tree = parse(source);

        ComponentSymbol componentSymbol = new ComponentSymbol();
        new SymbolTableInitializerVisitor(componentSymbol, source).visit(tree);
        componentsSymboleTable.setSymbol(componentSymbol, source);
    }

    private static void setSymbolTables(String path) throws IOException {
        File folder = new File(path);
        File[] files = folder.listFiles();
        if (files == null) return;

        java.util.Arrays.sort(files, java.util.Comparator.comparing(File::getPath));
        for (File f : files) {
            if (f.isDirectory()) {
                setSymbolTables(f.getPath());
            } else {
                setSymbolTable(f);
            }
        }
    }

    /* =================== AST + CodeGen =================== */

    private static void processFile(File file) throws IOException {
        String source = file.getPath();
        ParseTree tree = parse(source);

        // 1) بناء AST عبر الـ Visitor
        Program program = (Program) new BaseVisitor(componentsSymboleTable, source).visit(tree);

        // 2) حفظ الـ AST كنص
        Path rel = relativeFromRoot(file); // مثال: comp/home/home.component.ts
        Path astOut = AST_DIR.resolve(rel).getParent() == null
                ? AST_DIR.resolve(stripExt(file.getName()) + ".ast.txt")
                : AST_DIR.resolve(rel.getParent()).resolve(stripExt(file.getName()) + ".ast.txt");

        writeText(astOut, program == null ? "(null Program)" : program.toString());

        // 3) توليد الكود (HTML + JS) إن وُجد
        if (program != null) {
            CodeResult result = program.generateCode(); // يفترض يرجّع HTML/JS
            if (result != null) {
                String html = safeGetHtml(result);
                String js   = safeGetJs(result);

                // نولّد مسارات الخرج بنفس هيكلية المجلدات
                String baseName = stripExt(file.getName());

                Path htmlOut = HTML_DIR.resolve(rel.getParent() == null
                        ? Paths.get(baseName + ".html")
                        : rel.getParent().resolve(baseName + ".html"));

                Path jsOut = JS_DIR.resolve(rel.getParent() == null
                        ? Paths.get(baseName + ".js")
                        : rel.getParent().resolve(baseName + ".js"));

                if (html != null && !html.isEmpty()) {
                    writeText(htmlOut, html);
                }
                if (js != null && !js.isEmpty()) {
                    writeText(jsOut, js);
                }
            }
        }
    }

    // نستخدم دوال مساعدة لتجنّب NullPointer إن كانت الواجهة مختلفة
    private static String safeGetHtml(CodeResult r) {
        try {
            return r == null ? null : r.html;
        } catch (Throwable t) {
            return null;
        }
    }
    private static String safeGetJs(CodeResult r) {
        try {
            return r == null ? null : r.js;
        } catch (Throwable t) {
            return null;
        }
    }

    private static void startProgram(String path) throws IOException {
        File folder = new File(path);
        File[] files = folder.listFiles();
        if (files == null) return;

        java.util.Arrays.sort(files, java.util.Comparator.comparing(File::getPath));
        for (File f : files) {
            if (f.isDirectory()) {
                startProgram(f.getPath());
            } else if (isTargetToPrint(f)) {
                processFile(f);
            }
        }
    }

    /* =================== Single-file test =================== */

    private static void startTest(String singleFilePath) throws IOException {
        File file = new File(singleFilePath);
        if (!file.exists() || !file.isFile()) {
            System.out.println(ColorsConsole.YELLOW + "File not found: " + singleFilePath + ColorsConsole.RESET);
            return;
        }
        processFile(file);
    }

    /* =================== Main =================== */

    public static void main(String[] args) throws IOException {
        LogHandler.clear();

        ensureDirs();

        System.out.println(ColorsConsole.YELLOW + "Scanning: " + new File(ROOT).getAbsolutePath() + ColorsConsole.RESET);

        // 1) بناء SymbolTable من ملفات .component.ts فقط
        setSymbolTables(ROOT);

        // 1.1) حفظ جداول الرموز في ملف
        // نفترض أن ComponentsSymboleTable#toString يعيد تمثيلاً نصياً للجدول.
        writeText(SYMBOLS_FILE, componentsSymboleTable.toString());

        // 2) معالجة كل ملفات .ts و .html: حفظ AST وتوليد HTML/JS
        startProgram(ROOT);

        // ملاحظة: لاختبار ملف واحد:
        // startTest("src/Tests/some/path/file.component.html");

        System.out.println(ColorsConsole.GREEN + "Outputs written to: " + DIST_DIR.toAbsolutePath() + ColorsConsole.RESET);
    }
}
