package Code_Generation;

public class CodeResult {
    public String html;
    public String js;

    public CodeResult(String html, String js) {
        this.html = html;
        this.js = js;
    }
}
