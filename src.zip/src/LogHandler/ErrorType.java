package LogHandler;

public enum ErrorType {
    PrparetyNotFound,PrparetyDefined,
    ComponentDefined,ComponentNotFound,
    MethodDefined,MethodNotFound,
    InputDefined,InputNotFound,
    ArgsMethodDefined
}
