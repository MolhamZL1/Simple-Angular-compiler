package LogHandler;

public class SemanticException extends RuntimeException {

    public SemanticException(String message) {
        super(message);
    }
}
