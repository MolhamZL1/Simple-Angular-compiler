package AST.ImportsClasses;

import AST.ASTNode;

public interface ImportStatement extends ASTNode {
}
