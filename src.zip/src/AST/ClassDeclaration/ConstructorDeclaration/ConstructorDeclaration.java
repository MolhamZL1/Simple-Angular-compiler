package AST.ClassDeclaration.ConstructorDeclaration;

import AST.ClassDeclaration.ClassStatment;

public interface ConstructorDeclaration extends ClassStatment {
}
