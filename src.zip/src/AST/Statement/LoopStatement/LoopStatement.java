package AST.Statement.LoopStatement;

import AST.ASTNode;
import AST.Statement.Statement;

public interface LoopStatement extends Statement {
}
