package AST.Statement;

import AST.ASTNode;

public interface Statement extends ASTNode {
}
