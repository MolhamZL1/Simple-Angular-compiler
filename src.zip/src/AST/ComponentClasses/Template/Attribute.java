package AST.ComponentClasses.Template;

import AST.ASTNode;

public interface Attribute extends ASTNode {
}
