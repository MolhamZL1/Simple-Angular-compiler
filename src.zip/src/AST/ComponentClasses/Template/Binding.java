package AST.ComponentClasses.Template;

public interface Binding extends Attribute{

}
