package AST.ExpressionsClasses;

import AST.ASTNode;
import AST.Statement.Statement;

public interface Expression extends Statement {
}
