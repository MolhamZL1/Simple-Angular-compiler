package AST;

import Code_Generation.CodeResult;

public interface ASTNode {
    CodeResult generateCode();
}
