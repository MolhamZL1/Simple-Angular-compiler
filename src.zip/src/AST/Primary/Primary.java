package AST.Primary;

import AST.ExpressionsClasses.Expression;

public interface Primary extends Expression {
}
