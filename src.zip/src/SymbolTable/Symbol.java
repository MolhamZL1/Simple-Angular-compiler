package SymbolTable;

import AST.ExpressionsClasses.Expression;

public interface Symbol {

    public String getName();

    public int getLine();
}
