package AST.ExpressionsClasses;

import Code_Generation.CodeResult;

public class LogicalExpr implements Expression{
    private Expression leftExpression;
    private Expression rightExpression;
    private String op;

    public LogicalExpr(Expression leftExpression, String op, Expression rightExpression) {
        this.leftExpression = leftExpression;
        this.rightExpression = rightExpression;
        this.op = op;
    }

    @Override
    public String toString() {
        return "\nLogicalExpr{" +
                "\nleftExpression=" + leftExpression +
                "\n, op='" + op + '\'' +
                "\n, rightExpression=" + rightExpression +
                "\n}";
    }

    @Override
    public CodeResult generateCode() {
        CodeResult l = leftExpression  != null ? leftExpression.generateCode()  : new CodeResult("", "");
        CodeResult r = rightExpression != null ? rightExpression.generateCode() : new CodeResult("", "");
        String expr = "(" + l.html + ") " + op + " (" + r.html + ")";
        return new CodeResult(expr, safe(l.js)+safe(r.js));
    }

    private static String safe(String s){ return s==null? "": s; }
}
