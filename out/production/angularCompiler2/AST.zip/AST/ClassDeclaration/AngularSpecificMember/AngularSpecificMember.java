package AST.ClassDeclaration.AngularSpecificMember;

import AST.ClassDeclaration.ClassStatment;

public interface AngularSpecificMember extends ClassStatment {
}
