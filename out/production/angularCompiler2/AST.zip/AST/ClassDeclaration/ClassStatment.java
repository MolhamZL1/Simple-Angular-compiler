package AST.ClassDeclaration;

import AST.ASTNode;

public interface ClassStatment extends ASTNode {
}
