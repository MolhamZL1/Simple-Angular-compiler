package AST.MethodDeclaration;

import AST.ASTNode;
import AST.ClassDeclaration.ClassStatment;

public interface MethodDeclaration extends ClassStatment {
}
