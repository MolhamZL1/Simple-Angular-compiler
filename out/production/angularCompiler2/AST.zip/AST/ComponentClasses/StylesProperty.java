package AST.ComponentClasses;

public interface StylesProperty extends MetadataProperty {
}
