package AST.ComponentClasses;

import AST.ASTNode;

public interface MetadataProperty extends ASTNode {

}
