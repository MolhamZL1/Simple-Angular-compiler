package AST.ComponentClasses.Template;

import AST.ASTNode;
import AST.ComponentClasses.MetadataProperty;

public interface TemplateProperty extends MetadataProperty {
}
