package AST.ComponentClasses.Template;

public interface Directive extends Attribute{
}
